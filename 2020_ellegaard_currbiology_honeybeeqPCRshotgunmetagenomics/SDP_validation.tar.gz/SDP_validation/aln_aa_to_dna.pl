#! /usr/bin/perl -w
use Bio::Align::AlignI;
use Bio::AlignIO;
use Bio::SimpleAlign;
use Bio::SeqIO;
use Bio::Align::Utilities qw(:all);
use Getopt::Long;
use Pod::Usage;

=head1 SYNOPSIS

perl aln_aa_to_dna.pl

=head1 DESCRIPTION

This script generates nucleotide-alignments from protein alignments, using bioperl. The script will first find file-names to be processed; The protein alignment files should follow the format *aln.fasta, and the corresponding nucleotide files should follow the format *.ffn. Both these files should have the same prefix, namely the OG group number from orthofinder. 

=cut

GetOptions(
    'help' => sub { pod2usage( -exitstatus => 0, -verbose => 2 ) },
);

#Get the names of all alignment files and nucleotides files in the directory.
my @aln_file_names;
my $dir = ".";
opendir(DIR, $dir) or die $!;
while(my $file = readdir(DIR)) {
    next unless (-f "$dir/$file");
    if ($file =~ /aln.fasta/) {
	push @aln_file_names,$file;
    }
}
my $nb_files = @aln_file_names;

#Open the protein alignment file
sub aln_objects {
    my $aln_file = $_[0];
    my $str = Bio::AlignIO->new(
                        -file => $aln_file,
                        -format => "fasta",
                        );
    my $aln = $str->next_aln();
    return $aln;
}

sub seq_hash {
    my $dna_file = $_[0];
    my $seq_in = Bio::SeqIO->new(
                      -file => $dna_file, 
                       -format => "fasta",
                       );
    my %dna_seq_obj;
    while (my $dna_obj = $seq_in->next_seq()) {
            my $header = $dna_obj->id;
            my $seq = $dna_obj->seq;
	    $dna_seq_obj{$header} = $dna_obj;
    }
    return \%dna_seq_obj;
}

#Process the files
my $i = 0;
while ($i < $nb_files) {
    my $aln_file = aln_objects($aln_file_names[$i]);
    my @split_filename = split("_",$aln_file_names[$i]);
    my $ffn_file = $split_filename[0].".ffn";
    my $seq_ref = seq_hash($ffn_file);
    my %seq_hash = %{$seq_ref};
    my $outfile_prefix = $split_filename[0];
    my $dna_aln = &aa_to_dna_aln($aln_file,\%seq_hash);
    my $alnIO = Bio::AlignIO-> new(
	-format => "fasta",
	-file => '>'.$outfile_prefix."_aln_nuc.fasta",
	);
    $alnIO->write_aln($dna_aln);
    ++$i;
}
