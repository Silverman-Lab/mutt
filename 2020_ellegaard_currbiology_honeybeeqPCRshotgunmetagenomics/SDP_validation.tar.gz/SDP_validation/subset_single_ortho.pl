#! /usr/bin/perl -w
use Getopt::Long;
use Pod::Usage;
pod2usage(-verbose => 2) if ((@ARGV==0)&&(-t STDIN));

=head1 SYNOPSIS

perl subset_single_ortho.pl apibac_single_ortho_filt_subset.txt C4S75.faa Ga0307799.faa Ga0312307.faa

=head1 DESCRIPTION

This script creates a subset of a single-copy ortholog file, containing only members specified by the locus-tag in the user-provided proteome files. Output is printed to stdout.

=cut

GetOptions(
    'help' => sub { pod2usage( -exitstatus => 0, -verbose => 2 ) },
) or pod2usage(2);

#Open single-ortholog file, and get lines

my $single_ortho=shift;
open(FILE, $single_ortho) or
    die "Cant open $single_ortho!";
my @ortho_lines = <FILE>;
close FILE;

#Get locus-tags of SDP members
my @faa_files = @ARGV;
my %prefixes;
foreach my $file(@ARGV) {
    my $prefix = substr $file, 0, -4;
    $prefixes{$prefix} = 1;
}

#Subset each ortholog-line to contain only SDP members

foreach my $line(@ortho_lines) {
    chomp($line);
    my @split = split(" ",$line);
    my $OG = shift @split;
    my @new_line = ();
    push @new_line,$OG;
    foreach my $gene(@split) {
	my @gene_split = split("_", $gene);
	if (exists $prefixes{$gene_split[0]}) {
	    push @new_line,$gene;
	}
    }
    print join(" ",@new_line),"\n";
}
