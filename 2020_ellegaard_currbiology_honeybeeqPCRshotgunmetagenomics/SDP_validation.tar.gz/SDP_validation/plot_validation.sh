Rscript plot_validation.R validation_plots_part1.pdf bifido_1_perc_id.txt bifido_2_perc_id.txt firm4_1_perc_id.txt firm4_2_perc_id.txt firm5_1_perc_id.txt firm5_2_perc_id.txt firm5_3_perc_id.txt firm5_4_perc_id.txt firm5_7_perc_id.txt

Rscript plot_validation.R validation_plots_part2.pdf gilli_1_perc_id.txt gilli_2_perc_id.txt gilli_3_perc_id.txt gilli_4_perc_id.txt gilli_5_perc_id.txt gilli_6_perc_id.txt snod_1_perc_id.txt snod_2_perc_id.txt api_1_perc_id.txt

Rscript plot_validation.R other_plots_I.pdf api_2_perc_id.txt api_3_perc_id.txt bapis_perc_id.txt bifido_3_perc_id.txt com_1_perc_id.txt com_2_perc_id.txt com_3_perc_id.txt firm5_5_perc_id.txt firm5_6_perc_id.txt

Rscript plot_validation.R other_plots_II.pdf fper_perc_id.txt gilli_7_perc_id.txt gilli_8_perc_id.txt gilli_9_perc_id.txt snod_2_perc_id.txt snod_3_perc_id.txt
