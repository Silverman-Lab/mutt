#! /usr/bin/perl -w
use strict;
use Bio::Seq;
use Bio::SeqIO;
use Bio::SearchIO;
use Getopt::Long;
use Pod::Usage;
pod2usage(-verbose => 2) if ((@ARGV==0)&&(-t STDIN));

=head1 SYNOPSIS

perl extract_core_orthologs_from_blast.pl OG0000477.blastn > OG0000477_plus.ffn

=head1 DESCRIPTION

This script creates a fasta-file of sequences in a blast-file (-outfmt 5). It is assumed that the blast-file was filtered with suitable thresholds in a previous step. One additional threshold is added though, namely that the query coverage should be at least 0.5 for a sequence to be printed. Wrap the script in a bash-loop to run on multiple blast-files.

=cut

GetOptions(
    'help' => sub { pod2usage( -exitstatus => 0, -verbose => 2 ) },
) or pod2usage(2);

#Read the blast-file
my $blast_in = Bio::SearchIO->new(
                      -file => $ARGV[0], 
                       -format => 'blastxml',
                       );

#Get a non-redundant list of trimmed sequences from database. Save in hit_seq hash.
my %hit_seq;
while( my $result = $blast_in->next_result ) {
  while( my $hit = $result->next_hit ) {
    while( my $hsp = $hit->next_hsp ) {
	my ($query_length) = $result->query_length;
	my ($gene_name) = $hit->name;
	my ($hit_length) = $hsp->length('total');
	my ($hit_seq) = $hsp->hit_string; 
	my $query_cov = $hit_length/$query_length;
	if ($query_cov > 0.5) { 
	    if (exists $hit_seq{$gene_name}) {
		next;
	    }
	    else {
		$hit_seq{$gene_name} = $hit_seq;
	    }
	}
    }  
  }
}


#Print out the fasta-files
my $outfile_prefix = substr $ARGV[0],0,-7;
my $output_file = $outfile_prefix.".plus.ffn";


my $seq_out = Bio::SeqIO->new(
                      -file => ">".$output_file,
                      -format => 'fasta'
                      );

my @gene_ids = keys %hit_seq;
foreach (@gene_ids) {
    my $hit_seq = $hit_seq{$_};
    $hit_seq =~ tr/-//d; #Remove gaps in the hit-sequence!
    my $seq_obj = Bio::Seq->new(-seq => $hit_seq,#
				-display_id => $_);
    $seq_out->write_seq($seq_obj);
}
