#! /usr/bin/perl -w
use Bio::SeqIO;
use Getopt::Long;
use Pod::Usage;
pod2usage(-verbose => 2) if ((@ARGV==0)&&(-t STDIN));

=head1 SYNOPSIS

perl extract_orthologs.pl Orthofile.txt --folder "firm5"

=head1 DESCRIPTION

This script extracts fasta-sequences from multi-fasta files, according to an orthofinder file. Output is re-directed to a folder named according to user-input. The output is a set of multi-fasta files, two files per ortholog group(dna and protein sequences, .ffn, .faa), named with the ortholog group identifer. 

Thus, in addition to the orthofile provided as input, the run directory must contain multi-fasta protein/dna files for all genomes in the orthofile, named with the prefix corresponding to their locus-tags (i.e. JF72.faa, JF72.ffn).

=cut

my $folder;
GetOptions(
    'help' => sub { pod2usage( -exitstatus => 0, -verbose => 2 ) },
    'f|folder:s' => \$folder,
) or pod2usage(2);

sub fasta_hash {
    my %proteins;
    my $seq_in = Bio::SeqIO->new(
	-file => $_[0],
	-format => "fasta",
	);
    while (my $seq_obj = $seq_in->next_seq()) {
	my $header = $seq_obj->id;
	my $gene_seq = $seq_obj->seq;
	$proteins{$header} = $gene_seq;
    }
    return \%proteins;
} 

#Open the orthofinder .txt file and get the prefixes contained within the orthofinder file
open (FILE, $ARGV[0]) or
  die "Can't open $ARGV[0]: $!";
my @ortho_file = <FILE>;

my %prefixes;
foreach (@ortho_file) {
    chomp;
    my @split = split(" ",$_);
    shift @split;
    foreach (@split) {
	my @split2 = split("_",$_);
	$prefixes{$split2[0]} = "yes";
    }
}
my @prefixes = keys %prefixes;
my $group_size = @prefixes;

#Get the locus-tags and fasta-sequences for all genes. Save nucleotide and protein sequences in separate arrays
my $i = 0;
my @fasta_refs_aa;
my @fasta_refs_dna;
while ($i < $group_size) {
    my $fasta_ref = fasta_hash($prefixes[$i].".faa");
    my $fasta_ref2 = fasta_hash($prefixes[$i].".ffn");
    push @fasta_refs_aa,$fasta_ref;
    push @fasta_refs_dna,$fasta_ref2;
    ++$i;
}

#Merge nucleotide and amino acid sequences into a single hash each
my %fasta_seqs_aa;
foreach (@fasta_refs_aa) {
    while (($k, $v) = each %$_) {
	$fasta_seqs_aa{$k} = $v;
    }
}
my %fasta_seqs_dna;
foreach (@fasta_refs_dna) {
    while (($k, $v) = each %$_) {
	$fasta_seqs_dna{$k} = $v;
    }
}

#Create multi-fasta output files

my $output_dir = $folder;
unless (mkdir $output_dir) {
    die "The output directory $output_dir could not be created!";
}
chdir($output_dir);
foreach (@ortho_file) {
    my @genes = split(" ",$_);
    my $og_group = shift @genes;
    my $og_group_chomp = substr $og_group,0,-1;
    open OUTFILE1, '>'.$og_group_chomp.".faa" or die $!;
    foreach (@genes) {
	print OUTFILE1 ">",$_,"\n",$fasta_seqs_aa{$_},"\n";
    }
    close OUTFILE1;
    open OUTFILE2, '>'.$og_group_chomp.".ffn" or die $!;
    foreach (@genes) {
	print OUTFILE2 ">",$_,"\n",$fasta_seqs_dna{$_},"\n";
    }
    close OUTFILE2;
}

