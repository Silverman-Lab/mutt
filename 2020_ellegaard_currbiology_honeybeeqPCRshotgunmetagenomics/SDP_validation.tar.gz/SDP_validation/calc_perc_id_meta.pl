#! /usr/bin/perl -w
use Bio::AlignIO;
use Bio::SimpleAlign;
use Bio::SeqIO; 
use Bio::SearchIO;
use Getopt::Long;
use Pod::Usage;
pod2usage(-verbose => 2) if ((@ARGV==0)&&(-t STDIN));

=head1 SYNOPSIS

perl calc_perc_id_meta.pl OG0000453.mel.plus_nr.ffn 

=head1 DESCRIPTION

This script will add metagenomic ORFs to core gene alignments, one at a time, and calculate the maximum percentage identity in the trimmed alignment for each sequence. When an SDP is only represented by a single genome (and there is therefore no core gene alignment), the ORFs are aligned de novo to the core gene representative.

Note, the script makes assumptions about file suffixes.

=cut

GetOptions(
    'help' => sub { pod2usage( -exitstatus => 0, -verbose => 2 ) },
);

my %sdp_members = (
'Ga0061079' => 'api_3',
'C4S75' => 'api_1',
'C4S76' => 'api_2',
'Ga0307799' => 'api_1',
'Ga0312307' => 'api_1',
'Ga0216351' => 'com_1',
'Ga0216349' => 'com_1',
'Ga0248239' => 'com_3',
'CIN' => 'com_2',
'Ga0070888' => 'firm4_1',
'Ga0227357' => 'firm4_1',
'Ga0227358' => 'firm4_1',
'Ga0227360' => 'firm4_1',
'Ga0072399' => 'firm4_2',
'Ga0326456' => 'firm4_1',
'Ga0226852' => 'firm5_5',
'Ga0061072' => 'firm5_6',
'Ga0226847' => 'firm5_6',
'Ga0307804' => 'firm5_7',
'Ga0312303' => 'firm5_7',
'Ga0311394' => 'firm5_7',
'Ga0312304' => 'firm5_7',
'Ga0226842' => 'firm5_1',
'Ga0072402' => 'firm5_1',
'Ga0061073' => 'firm5_1',
'Ga0133563' => 'firm5_1',
'Ga0133561' => 'firm5_2',
'Ga0072400' => 'firm5_2',
'LACWKB8' => 'firm5_2',
'Ga0226840' => 'firm5_3',
'Ga0227359' => 'firm5_3',
'Ga0133562' => 'firm5_3',
'Ga0072404' => 'firm5_3',
'Ga0225908' => 'firm5_3',
'Ga0070887' => 'firm5_4',
'Ga0226839' => 'firm5_4',
'Ga0133564' => 'firm5_4',
'LACWKB10' => 'firm5_4',
'Ga0072403' => 'firm5_4',
'BBC0122' => 'bapis',
'BBC0178' => 'bapis',
'BBC0244' => 'bapis',
'PEB0122' => 'bapis', 
'PEB0149' => 'bapis', 
'PEB0150' => 'bapis',
'BINDI' => 'bifido_2', 
'BCOR' => 'bifido_2', 
'BAST' => 'bifido_1', 
'Ga0056940' => 'bifido_3', 
'Ga0057557' => 'bifido_3', 
'Ga0072395' => 'bifido_1', 
'Ga0072396' => 'bifido_1', 
'Ga0072398' => 'bifido_2', 
'Ga0072401' => 'bifido_1', 
'Ga0098206' => 'bifido_3', 
'Ga0133549' => 'bifido_1', 
'Ga0133550' => 'bifido_2', 
'Ga0133551' => 'bifido_1', 
'Ga0133552' => 'bifido_1', 
'Ga0133553' => 'bifido_1', 
'Ga0312305' => 'bifido_1', 
'Ga0133554' => 'fper',
'Ga0077910' => 'fper',
'A9G07' => 'gilli_6',
'A9G08' => 'gilli_6',
'A9G09' => 'gilli_7',
'A9G10' => 'gilli_4',
'A9G11' => 'gilli_8',
'A9G12' => 'gilli_8',
'A9G13' => 'gilli_8',
'A9G14' => 'gilli_1',
'A9G15' => 'gilli_2',
'A9G16' => 'gilli_2',
'A9G17' => 'gilli_1',
'A9G19' => 'gilli_2',
'A9G23' => 'gilli_9',
'A9G24' => 'gilli_9',
'A9G31' => 'gilli_9',
'A9G35' => 'gilli_9',
'A9G43' => 'gilli_9',
'A9G47' => 'gilli_9',
'B6C96' => 'gilli_2',
'B6C99' => 'gilli_2',
'B6D03' => 'gilli_1',
'B6D08' => 'gilli_1',
'B6D14' => 'gilli_2',
'B6D17' => 'gilli_2',
'B6D18' => 'gilli_2',
'B6D19' => 'gilli_1',
'B6D21' => 'gilli_2',
'B6D22' => 'gilli_1',
'Ga0055041' => 'gilli_9',
'Ga0061080' => 'gilli_9',
'Ga0133555' => 'gilli_2',
'Ga0133556' => 'gilli_2',
'Ga0133557' => 'gilli_3',
'Ga0133558' => 'gilli_3',
'Ga0133559' => 'gilli_1',
'Ga0227298' => 'gilli_9',
'Ga0227301' => 'gilli_9',
'Ga0227302' => 'gilli_9',
'Ga0307800' => 'gilli_5',
'Ga0307802' => 'gilli_4',
'Ga0307803' => 'gilli_6',
'GAPWK' => 'gilli_1',
'BGH94' => 'snod_1',
'BGH96' => 'snod_1',
'BGI00' => 'snod_1',
'BGI01' => 'snod_1',
'BGI08' => 'snod_1',
'BGI09' => 'snod_1',
'BGI12' => 'snod_1',
'BGI13' => 'snod_1',
'BHC43' => 'snod_2',
'BHC44' => 'snod_3',
'BHC47' => 'snod_1',
'BHC48' => 'snod_3',
'BHC50' => 'snod_1',
'BHC52' => 'snod_1',
'BHC53' => 'snod_2',
'BHC54' => 'snod_2',
'BHC57' => 'snod_3',
'CPT77' => 'snod_1',
'Ga0227304' => 'snod_1',
'Ga0227305' => 'snod_1',
'Ga0227306' => 'snod_1',
'Ga0227310' => 'snod_3',
'Ga0326500' => 'snod_1',
'SALWKB12' => 'snod_3',
'SALWKB2' => 'snod_1',
'Ga0216357' => 'bom_2',
'Ga0308518' => 'bom_3',
'Ga0372762' => 'bom_1',
'Ga0098617' => 'lkun',
'Ga0308523' => 'lkun',
);

#Sub-routines

sub fasta_seq {
    my $file = $_[0];
    my %seq_hash;
    my $seq_in = Bio::SeqIO->new(
                      -file => $file, 
                       -format => 'fasta',
                       );
    while(my $seq_obj = $seq_in->next_seq()) {
	my $header = $seq_obj->id;
	my $seq = $seq_obj->seq;
	$seq_hash{$header} = $seq;
    }
    return \%seq_hash;
}

sub aln_objects {
    my $aln_file = $_[0];
    my $str = Bio::AlignIO->new(
                        -file => $aln_file,
                        -format => "fasta",
                        );
    my $aln = $str->next_aln();
    return $aln;
}

sub max_id {
    my $aln = $_[0];
    my $ortho = $_[1]; #The metagenomic ORF
    my @core_seqs = @{$_[2]}; #The core sequences in the db (for the specific OG)
    my %max_id;
    my %closest_strain;
    my $max_id = 0;
    my $closest_strain;
    foreach my $core_seq(@core_seqs) {
	my $aln_temp = $aln->select_noncont_by_name($ortho, $core_seq);
	my $aln_temp_prune = $aln_temp ->remove_gaps;
	my $perc_id =  $aln_temp_prune ->percentage_identity;
	if ($perc_id > $max_id) {
	    $max_id = $perc_id;
	    $closest_strain = $core_seq;
	}
    }
    my $max_id_round = sprintf("%.2f", $max_id);
    $max_id{$ortho} = $max_id_round;
    $closest_strain{$ortho} = $closest_strain; 
    return (\%max_id, \%closest_strain);
}

sub blast_db {
    my $ortho_file = $_[0]; #Name of fasta-file containing the metagenomic ORF
    my $blast_file = "temp.blastn";
    `blastn -db /home/kirsten/Bee_metagenome_databases/db_190415 -query $ortho_file -outfmt 5 > $blast_file`;
    my $blast_in = Bio::SearchIO->new(-file => "temp.blastn", -format => 'blastxml');
    my $result = $blast_in->next_result; 
    my $hit = $result->next_hit;
    my $hsp = $hit->next_hsp;
    my ($gene_name) = $hit->name;
    `rm temp.blastn`;
    return($gene_name);
}

#Get the names of the ortholog sequences. If there arent any, exit the script.
my $ffn_plus_file = shift;
my $ffn_plus_ref = fasta_seq($ffn_plus_file);
my %ffn_plus = %{$ffn_plus_ref};
my @orthologs = keys %{$ffn_plus_ref};
my $nb_orthologs=@orthologs;
if ($nb_orthologs == 0) { 
    exit;
}
my $prefix = substr $ffn_plus_file, 0, 9;
my $ffn_file = $prefix.".ffn";
my $ffn_ref = fasta_seq($ffn_file);
my %ffn = %{$ffn_ref};
my $nb_core = keys %ffn;
my @core_ids = keys %ffn;

my $i=1;
foreach my $ortholog(@orthologs) {
    my $temp_file = "temp_".$i.".fasta";
    my $temp_aln = "temp_".$i."_aln.fasta";
    open OUTFILE, ">".$temp_file or die $!;
    print OUTFILE ">",$ortholog,"\n",$ffn_plus{$ortholog},"\n";
    my $best_hit = blast_db($temp_file);
    my $closest_sdp = $sdp_members{$best_hit};
    if ($nb_core == 1) {
	print OUTFILE ">",$core_ids[0],"\n",$ffn{$core_ids[0]},"\n";
	close OUTFILE;
	`mafft --auto $temp_file > $temp_aln`;
    }
    else {
	close OUTFILE;
	my $core_aln = $prefix."_aln_nuc.fasta";
	`mafft --addfragments $temp_file $core_aln > $temp_aln`;
    }    
    my $aln = aln_objects($temp_aln);
    max_id($aln,$ortholog,\@core_ids);
    my ($max_id, $closest_strain) = max_id($aln,$ortholog,\@core_ids);
    my %max_id = %$max_id;
    my %closest_strain = %$closest_strain;
    my $result_line = $prefix."\t".$ortholog."\t".$closest_strain{$ortholog}."\t".$max_id{$ortholog}."\t".$closest_sdp;
    print $result_line,"\n";
    ++$i;
    `rm temp_*`;
}
