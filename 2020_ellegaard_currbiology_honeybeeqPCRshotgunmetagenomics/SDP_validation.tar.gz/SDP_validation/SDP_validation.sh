#!/bin/bash

#This bash-script shows how the perl-scripts in the current directory were combined for metagenomic validation of candidate SDPs, exemplified with Apibacter. Directories for each candidate SDP must be prepared in advance, containing nucleotide and protein sequences for the genes of all the genomes assigned to the candidate SDP. Validation is based on filtered single-copy core gene families, which must also be provided (in this example, the script will use subset containing the first 10 filtered core gene families for Apibacter). The script uses the following software: mafft, blast, cd-hit, in addition to multiple perl-scripts with associated modules.

#Declare the candidate SDPs
declare -a names=(
'api_1'
#'api_2'
#'api_3'
);

#Extract core ortholog sequences for each SDP, align at amino acid level and back-translate (if there are multiple members within SDP). Simplify seq-names in alignment files
for i in ${names[@]};do
    SDP=$i
    cd $SDP
    NB=$( ls *faa | wc -l)
    ORTHOFILE=$SDP"_single_ortho.txt"
    FAA=$(ls *faa)
    perl ../subset_single_ortho.pl ../apibac_single_ortho_filt_subset.txt $FAA > $ORTHOFILE
    perl ../extract_orthologs.pl $ORTHOFILE --folder "core_sequences"
    if [ $NB != 1 ]; then
	cd "core_sequences"
	for j in $(ls *.faa); do
	    OG=${j:0:(-4)}
	    mafft --auto --anysymbol $j > $OG"_aln.fasta"
	done
	perl  ../../aln_aa_to_dna.pl
	for k in $(ls *aln_nuc.fasta); do
	    sed -i 's/_.*$//g'  $k
	done
	cd ..
    fi
    cd ..
done

#Blast core sequences against ORF databases (mellifera & cerana), and extract non-redundant orthologous ORF sequences
for i in ${names[@]};do
    SDP=$i
    cd $SDP/"core_sequences"
    for j in $(ls *ffn); do
	OG=${j:0:9}
	echo -e $SDP"\t"$OG
	#Simplify sequence names in ffn-files
	sed -i 's/_.*$//g' $j
	#Blast ffn-files against ORF database
	blastn -db ../../../databases/ORFs.ffn -query $j -outfmt 5 -evalue 1e-5 -perc_identity 70 > $OG".blastn"
	#Extract orthologs from blast-files
	if [ -s $OG".blastn" ]; then
	    perl ../../extract_orthologs_from_blast.pl $OG".blastn"
	    if [ -s $OG".plus.ffn" ]; then
		~/Software/cdhit/cd-hit -i $OG".plus.ffn" -c 0.99 -o  $OG".plus_nr.ffn"
		fi
	fi
    done
    cd ../../
done

#Calculate max percentage id between non-redundant orthologous ORFs and core sequences

for i in ${names[@]};do
    SDP=$i
    cd $SDP/"core_sequences"
    NB=$( ls *plus_nr.ffn | wc -l)
    echo -e "OG_group\tMeta_ORF\tClosest_OG_member\tPerc_id\tClosest_SDP_db" >> $SDP"_perc_id.txt"
    if [ $NB -gt 0 ]; then
	for j in $(ls *plus_nr.ffn); do
	    perl ../../calc_perc_id_meta.pl $j >> $SDP"_perc_id.txt"
	done
    fi
    cd ../../
done
