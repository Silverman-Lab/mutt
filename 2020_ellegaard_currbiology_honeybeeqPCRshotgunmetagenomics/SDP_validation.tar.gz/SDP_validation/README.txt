##Overview

In this directory, the workflow for metagenomic validation of candidate SDPs is described, and the final output files are provided.

#Metagenomic validation workflow

Metagenomic validation was done individually for each candidate SDP, in this directory the workflow is demonstrated for Apibacter (candidate SDP "api_1"). The pipeline uses multiple perl-scripts (provided in the current directory), in addition to the following software: blast, mafft, cd-hit.

The bash-script "SDP_validation.sh" details shows how the pipeline was executed, with intermediate output-files given in the sub-directory "api_1". In brief, the pipeline works as follows:

1. The file containing filtered single-copy core gene families is subset for the genomes associated with the candidate SDP
2. multi-fasta files corresponding to the subset ortholog file are generated, aligned at the protein level, and back-translated to nucleotide alignments
3. All the sequences within each multi-fasta file are used as queries in a blastn search against all predicted metagenomic ORFs, sequences for significant hits are recruited
4. Redundancy among recruited metagenomic ORFs is removed with CD-HIT (clustering threshold 99% nucleotide sequence identity)
5. For each recruited metagenomic ORF, the maximum percentage identity to the core gene sequences from the database is calculated.

Note, this pipeline can take several days, when run on the complete data-set.

#Final output files and plots

The final output file of the validation pipeline is a file containing the maximum percentage identity for all the non-redundant recruited metagenomic ORFs towards the core gene sequences of the candidate SDP. These files are provided in the current directory, with the suffix "*perc_id.txt", and contain the following five columns:

OG_group: The identifier of the single-copy ortholog gene-family used for the recruitment
Meta_ORF: the identifier of the recruited ORF (which includes the sample affiliation)
Closest_OG_member: the locus-tag of the closest core gene sequence in the genomic database
Perc_id: the alignment percentage identity to the closest core gene sequence in the genomic database
Closest_SDP_db: The SDP affiliation of the cloesest core gene sequence in the genomic database

Density distribution plots for these files can be generated with the R-script "plot_validation.R" (see "plot_validation.sh", for example usage).

A candidate SDP is considered confirmed, when the following two criteria are met:

1. Metagenomic ORFs with more than 95% sequence identity were recruited (meaning that the candidate SDP was present in one or more samples)
2. Recruited ORFs have a consistently higher sequence identity to the candidate SDP than to any other SDPs within the database, as indicated by discrete density distributions (meaning that the candidate SDP is discrete relative to all other SDPs in the database)

