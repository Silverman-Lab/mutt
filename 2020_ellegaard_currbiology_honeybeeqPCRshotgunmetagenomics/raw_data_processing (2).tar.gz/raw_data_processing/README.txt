##Overview

In this directory, the commands used for quality check and filtering of raw data are provided. Raw data is available on the sequence read archive (PRJNA598094). Summary info on the sequencing run is provided in the file:

"Run_Summary.txt"

#Quality checks

The quality of the raw data was evaluated both before and after trimming with FastQC (v0.11.4). Overall, the phred scores was high, as is typical for HiSeq data. Some duplication observed, likely due to very deep sequencing of dominant community members (therefore duplicates were not removed). Partial adapters were present on several reads. Based on these results, end-trimming and removal of adapter sequences were performed with trimmomatic.

#Trimmomatic (Version 3)

Example command:

java -jar trimmomatic-0.35.jar PE -threads 10 AmAi01_R1.fastq.gz AmAi02_R2.fastq.gz AmAi01_paired_R1.fastq.gz AmAi01_unpaired_R1.fastq.gz AmAi02_paired_R2.fastq.gz AmAi02_unpaired_R2.fastq.gz ILLUMINACLIP:NexteraPE-PE.fa:2:30:10 LEADING:28 TRAILING:28  MINLEN:60 


